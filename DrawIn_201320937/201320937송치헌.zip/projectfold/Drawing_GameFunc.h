#pragma once
/*
#include "SDL.h"

void Init_Intro();
void HandleEvents_Intro();
void Update_Intro();
void Render_Intro();
void ClearGame_Intro();


void InitGame_Stage();
void HandleEvents_Stage();
void Update_Stage();
void Render_Stage();
void ClearGame_Stage();


void Init_Ending();
void HandleEvents_Ending();
void Update_Ending();
void Render_Ending();
void ClearGame_Ending();
*/

