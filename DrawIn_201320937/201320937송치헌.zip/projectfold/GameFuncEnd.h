#pragma once

#include "SDL.h"

void Init_End();
void HandleEvents_End();
void Update_End();
void Render_End();
void ClearGame_End();