#pragma once

const int PHASE_INTRO = 0;
const int PHASE_STAGE1 = 1;
const int PHASE_ENDING = 2;


extern int g_current_game_phase;
