#pragma once

#include "SDL.h"

void Init_Intro();
void HandleEvents_Intro();
void Update_Intro();
void Render_Intro();
void ClearGame_Intro();