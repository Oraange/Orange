#pragma once

#include "SDL.h"

void InitGame_Stage();
void HandleEvents_Stage();
void Update_Stage();
void Render_Stage();
void ClearGame_Stage();